﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace demoAttack
{
    class Program
    {
        static void Main()
        {
            char again = 'y';
            while (again == 'y')
            {
                if (!worker.returnStatement())
                    Console.WriteLine("\nFALSE");
                else
                    Console.Write("\nTRUE");

                again = Console.ReadKey().KeyChar;
            }
        }
    }

    public class worker
    {
        public static bool returnStatement()
        {
            return false;
        }
    }
}
