﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace attackingDemo
{
    class Program
    {
        public static void Main()
        {
            MethodInfo targetMethod = overWrite();
            System.Runtime.CompilerServices.RuntimeHelpers.PrepareMethod(targetMethod.MethodHandle); //JIT the method just incase it has not been
            writeFunction(targetMethod.MethodHandle.GetFunctionPointer());
        }


        static MethodInfo overWrite()
        {
            return typeof(demoAttack.worker).GetMethod("returnStatement");
        }

        static public byte[] returnTrue = new byte[]
        {
            0x31, 0xc0,       //xor eax, eax &
            0x40,             //inc eax
            0xc3  //ret
        };

        public static void writeFunction(IntPtr targetAddress)
        {
            for (int i = 0; i < returnTrue.Length; i++)
            {
                System.Runtime.InteropServices.Marshal.WriteByte(new IntPtr(targetAddress.ToInt64() + i), returnTrue[i]);
            }
        }
    }
}
