#=============================================================================#
# This script can output the correct hash value for any single API
# function for use in ROR13. 
#
# Example: Detect fatal collisions against all modules in the C drive:
#     >hash.py /dir c:\
#
# Example: List the hashes for all exports from kernel32.dll (As found in 'c:\windows\system32\')
#     >hash.py /mod c:\windows\system32\ kernel32.dll
#
# Author: Stephen Fewer (stephen_fewer[at]harmonysecurity[dot]com)
#
# Edited by Topher Timzen to support his form of ROR13 on Apr 16 12:15:36
#=============================================================================#
from sys import path
import os, time, sys
import pefile

modules_scanned = 0
functions_scanned = 0
#=============================================================================#
def ror( dword, bits ):
  return (( dword >> bits | dword << ( 32 - bits ) ) & 0xFFFFFFFF)
#=============================================================================#
def hash( module, function, bits=13, print_hash=True ):
  function_hash = 0
  for c in str( function ):
    function_hash  = ror( function_hash, bits ) 
    function_hash  = (function_hash + ord(c))
  
  if print_hash:
    function_hash = function_hash & 0xFFFFFFFF
    print "[+] 0x%02X = %s!%s" % ( function_hash, module.lower(), function )
  return function_hash
#=============================================================================#
def scan( dll_path, dll_name, print_hashes=False, print_collisions=True ):
  print "IN SCAN"
  global modules_scanned
  global functions_scanned
  try:
    dll_name = dll_name.lower()
    modules_scanned += 1
    pe = pefile.PE( os.path.join( dll_path, dll_name ) )
    for export in pe.DIRECTORY_ENTRY_EXPORT.symbols:
      if export.name is None:
        continue
      h = hash( dll_name, export.name, print_hash=print_hashes )
      functions_scanned += 1
  except:
    pass
#=============================================================================#
def main( argv=None ):
  if not argv:
    argv = sys.argv
  try:
    if len( argv ) == 1:
      print "Usage: hash.py [/mod <path> <module.dll>] | [<module.dll> <function>]"
    else:
      print "[+] Ran on %s\n" % (  time.asctime( time.localtime() ) )
      if argv[1] == "/mod":
        print "[+] Scanning module '%s' in directory '%s'..." % ( argv[3], argv[2] )
        scan( argv[2], argv[3], print_hashes=True )
      else:
        hash( argv[1], argv[2] )
  except Exception, e:
    print "[-] ", e
#=============================================================================#
if __name__ == "__main__":
  main()
#=============================================================================#